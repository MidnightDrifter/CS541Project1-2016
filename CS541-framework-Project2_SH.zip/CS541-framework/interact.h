void InitInteraction();
