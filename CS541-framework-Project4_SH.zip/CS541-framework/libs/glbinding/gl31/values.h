#pragma once

#include <glbinding/nogl.h>
#include <glbinding/gl/values.h>


namespace gl31
{

using gl::GL_INVALID_INDEX;


} // namespace gl31
