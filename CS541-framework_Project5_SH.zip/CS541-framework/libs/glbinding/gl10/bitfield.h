#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/bitfield.h>

namespace gl10
{

// import bitfields to namespace


} // namespace gl10
